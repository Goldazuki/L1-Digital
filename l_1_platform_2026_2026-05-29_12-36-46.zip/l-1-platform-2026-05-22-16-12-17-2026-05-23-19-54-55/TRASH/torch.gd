extends AnimatedSprite2D

func _ready():
	play("flame")
