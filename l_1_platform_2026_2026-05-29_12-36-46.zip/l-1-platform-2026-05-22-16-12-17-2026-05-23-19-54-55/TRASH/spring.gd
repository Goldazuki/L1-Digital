extends Area2D
@onready var animation: AnimatedSprite2D = $AnimatedSprite2D

var JUMP_VELOCITY = -400.0

func _on_body_entered(body: Node2D) -> void:
	if body.name == "player":
		# Make the player bounce only if hit from above
		if body.global_position.y < global_position.y:
			body.bounce(-800)
			animation.play("jump")


func _on_body_exited(body: Node2D) -> void:
		animation.play("idle")
