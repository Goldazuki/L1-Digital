extends Node2D

@onready var army_prefab = preload("res://Prefabs/army_man.tscn")

# Called when the node enters the scene tree for the first time.
func _on_enemy_timer_timeout() -> void:
	var army_men = army_prefab.instantiate()
	# positioning it
	var random_x = randi_range(-1450, 1750)
	var random_y = randi_range(-350, 1250)
	army_men.position = Vector2(random_x, random_y)
	add_child(army_men)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
