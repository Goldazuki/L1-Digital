extends Area2D

@export var speed = 10

func _process(delta: float) -> void:
	if Input.is_action_pressed("player_up"):
		position.y -= speed
	if Input.is_action_pressed("player_down"):
		position.y += speed
	if Input.is_action_pressed("player_left"):
		position.x -= speed
	if Input.is_action_pressed("player_right"):
		position.x += speed
