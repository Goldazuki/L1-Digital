extends CharacterBody2D
@export var player: Node2D

const SPEED = 100.0


func _physics_process(delta: float) -> void:
	# Where is the player?
	var direction = (player.global_position - global_position).normalized()
	velocity = direction * SPEED
	move_and_slide()
